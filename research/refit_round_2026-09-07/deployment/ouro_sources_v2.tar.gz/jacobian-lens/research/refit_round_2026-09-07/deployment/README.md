# Rental preparation — 8 September 2026

The user accepted the proposed $20 combined budget and said they would arrange the funds: $10 for five Ouro N100 fits and $10 for the conditional Huginn R8 N100 pilot. Funding availability has not been checked. The user subsequently requested notification before renting. **Notify the user immediately before any rental, stating the GPU, actual hourly rate and $20 combined limit.** This preparation has created no Pod, queried no account and incurred no cloud spending.

The source bundle stages the optimized fitting runner, five frozen calibration sets, pinned model-file hashes, an exact dependency lock and verification evidence. It excludes weights, credentials and existing Jacobian binaries. All original project files remain unchanged. The first archive, `ouro_sources.tar.gz`, is retained as V1; its CPU-check dependencies were incomplete. V2 includes the existing `tests/tiny.py` and `tests/__init__.py` needed by those checks.

## Environment and source identity

Use a fresh, normal GIL-enabled CPython 3.14.7 environment on Linux x86_64 with glibc >=2.28. [environment.json](environment.json) binds 46 matched package versions, the Torch commit, CUDA build and cuDNN runtime. [requirements.lock](requirements.lock) names exact wheel URLs and SHA-256 hashes. All 46 candidates were available in a local pip dry run; parsing confirmed every locked requirement has a hash. The two large Torch/Triton archives were downloaded locally and independently hashed; Torch's CPU/CUDA libraries, extension and version file match the installed validation build byte for byte. See [wheels.json](wheels.json) and [wheel_candidates.json](wheel_candidates.json). The other candidate archive hashes came from pip/public indexes; they have not all been downloaded here. No fresh environment or rental GPU has yet been validated.

Install into the fresh environment with `python -m pip install --no-deps --require-hashes -r requirements.lock`. The lock already includes the dependency closure. Use bundled J-Lens sources on `PYTHONPATH`. Its current project metadata requests Transformers >=5.5, whereas the validated model uses 4.54.1; a normal dependency-resolving installation would change the experiment. The old Ouro runtime lock also specifies a different Torch build. [ENVIRONMENT.md](ENVIRONMENT.md) and [environment_portability.json](environment_portability.json) preserve the independent audit before the subsequent wheel downloads.

The unchanged Ouro adapter and J-Lens package are included under `ouro_project/src` and `jacobian-lens`. [model_manifest.json](model_manifest.json) records every file of the pinned `ByteDance/Ouro-2.6B` snapshot, revision `1ed04250da1a9936042725d302e81c8fa2ab5abd`: 13 files totaling 5,341,718,984 bytes. Transfer the existing snapshot, or obtain that exact public revision and verify it. The runner accepts an explicit snapshot path and hashes its full membership and contents before model loading. Do not substitute an unpinned remote-code checkout.

## Fitting runner

[run_spec.json](run_spec.json) freezes all five disjoint N100 lists, seeds, ordered token counts, source hashes and numerical settings: B8, four loops, sources 0–190, target 191, T128, skip16, native BF16 computation, CUDA replay and verified saved-tensor compression. The mean gives each paragraph equal weight. No calibration example may be skipped or replaced.

[run_refits.py](run_refits.py) accepts `--all` or a single `--fit-id`. Its `--plan` mode validates the small manifests and calibration/source identities using only the standard library, without loading a model or creating output directories. From an extracted bundle:

```bash
export PYTHONPATH="$PWD/jacobian-lens:$PWD/ouro_project/src"
python jacobian-lens/research/refit_round_2026-09-07/deployment/run_refits.py \
  --plan --all --ouro-src "$PWD/ouro_project/src" \
  --snapshot /path/to/the/pinned/snapshot \
  --output-dir "$PWD/results/ouro-refits"
```

After the separately required rental-GPU benchmark/parity checks, execution uses the same command without `--plan`, with `--stop-at-utc` set from the actual rental start time, rate, storage charges and remaining Ouro allocation. Execution refuses a missing deadline. Set `PYTORCH_ALLOC_CONF=expandable_segments:True` consistently with the validated configuration. The runner fixes CPU threads at eight and interop threads at one. It records actual precision, attention, device and software settings and binds one shared production runtime across all five fits.

Every completed paragraph produces a new FP32 checkpoint generation. The binary, metadata and seal are flushed before an atomic pointer commits them. Resume checks hashes, the exact ordered prefix and counts before loading with `weights_only=True`. Signals and deadlines stop between paragraphs. Unsealed attempts remain available for inspection. Only verified, owned older checkpoints are pruned: two are kept while active, then one final FP32 sum after the FP16 N100 lens is sealed. A second process cannot concurrently own the same output tree. The final artifact must equal the FP16 conversion of the sealed FP32 sum divided by 100, and a matching completed rerun validates it before returning without computation.

The CPU harness in [verify_estimators.py](../design_audit/verify_estimators.py), invoked with `--check-runner`, tests actual N100 orchestration using tiny matrices. It covers unequal valid-position counts with equal paragraph weighting, stop/resume, every checkpoint/final commit stage, corrupted artifacts, changed inputs, wrong counts, overflow and a competing process lock. [cli_checks_v1.json](cli_checks_v1.json) separately checks the standard-library plan, invalid manifests/settings, overlapping calibration lists, missing deadlines and shared runtime identity. These are orchestration checks, not a GPU numerical validation.

## Before and during paid execution

First notify the user and confirm that the account has the arranged funds. Run a complete fixed-paragraph timing and matching-batch native-versus-optimized comparison on the selected GPU before fitting. The local laptop tensors are not a cross-GPU bitwise reference. Preserve the historical B32/new B8 comparability issue in subsequent interpretation. Project the entire fitting loop, including checkpoint writes and evaluation, against the allocation.

The runner's deadline is a between-paragraph stop mechanism. It does not terminate a Pod or enforce the provider's bill. The launch controller must track total lease time and storage, leave time to retrieve and verify artifacts, and terminate the resource within the agreed budget. A process exit alone does not stop rental charges. No such controller has been run in this preparation.

The old `fit_lens.py` is included as a reuse reference and selects the stock engine. Its evaluator also expects the old sidecar schema; it cannot directly consume the new `COMPLETE.json` generation. The FP16 lens binary itself remains compatible with `JacobianLens.load`. A new evaluation adapter must validate the new seals and call the unchanged concept extraction/ranking/scoring functions separately for each fit. Do not fabricate an old sidecar or average fitted matrices before nonlinear scoring. This bundle prepares fitting; it does not assert that the new evaluation adapter or Huginn adapter is complete.

Ouro target/position checks and Huginn retain their original order and scientific conditions. The budget quote does not silently add controls or five Huginn fits. No new scientific calibration lens or recovery result has been produced by this preparation.
