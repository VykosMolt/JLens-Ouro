# Frozen experiment deployment — 8 September 2026

**Current status, 20:02 UTC:** attempt04's main Ouro profile passed full B8 bitwise parity, but the next profile stopped at the host-memory guard. All 11 result files were retrieved and hash-verified; termination was confirmed at 19:49 UTC. The preflight allocator cleanup passed 73 CPU checks and independent review; the retry requests at least 64 GB host RAM at the same $0.22/GPU-hour ceiling. No calibration fit or new recovery result has run. The complete GPU preflight and timing projection still precede fitting. Explicit user transfer and rental authorization remains in force under the combined $25 cap. The [run log](../RUN_LOG.md) records the evidence and failure. The preparation snapshot below predates these attempts.

The user authorized autonomous rental and execution with a **$25 combined ceiling**, and confirmed funding. A read-only account check confirmed sufficient funds and no existing Pods. Notify the user immediately before creating a Pod, naming the selected GPU and live hourly price. No paid Pod has been created at this preparation checkpoint.

The workload is five independent Ouro N100 final-target fits, one N100 penultimate-target control, one paired N100 sampled-sum/diagonal control, and one Huginn R8 N100 fit followed by both frozen evaluation seeds. The paired control shares one derivative stream. This is 700 Ouro paragraph computations, 100 Huginn paragraph computations and nine saved map banks. [combined_contract.json](combined_contract.json) fixes the geometry, seeds, calibration reuse and comparison support before outcomes.

## Runtime and evidence

The base image is the official Python image pinned by digest in `lease.py`, with CPython3.14.7. A fresh instance installed all46 exact wheel hashes from [requirements.lock](requirements.lock) and passed environment, checkpoint runner, paired-control, Huginn adapter and evaluator CPU checks. [fresh_environment_v1.json](fresh_environment_v1.json) records the runtime proof. The local SSH bootstrap also passed full public-key authentication. These checks loaded no real model weights or CUDA locally.

The model manifests cover every byte of the pinned public Ouro and Huginn snapshots. The bundle contains original model adapters, JLens sources, evaluation stimuli, all calibration lists and deployment code. It contains no credentials, pretrained weights or historical Jacobian binaries. All original project files remain unchanged. Earlier V1/V2 archives are retained; V3 is the combined source closure.

[run_spec.json](run_spec.json) binds B8, native BF16 operations, all output directions, CUDA replay and verified saved-activation compression. Main fits keep all191 strict sources. Each paragraph contributes equally to its FP32 mean. Completed FP16 lenses must literally equal the sealed FP32 sum divided by100. Every paragraph commits a durable checkpoint generation; signals/deadlines stop safely, and completed fits are immutable. No sample may be skipped or replaced.

All evaluators validate the producer identities and binary seals, preserve the original rank/control calculation, and score each independent map bank separately. Penultimate comparisons use common learned support0..189; the unsupported self-column is excluded on both sides. The paired position control uses the same frozen q for its two arms. Huginn uses its native BOS/tokenizer, all32 core cells at R8, full-sequence coda readout and the frozen common token eligibility. Controls are conditional on fit01; the two Huginn seeds assess initialization sensitivity with one fitted bank.

## Execution and spending

[lease.py](lease.py) currently selects one RTX3090 Community Pod at no more than$0.22/GPU-hour, with at least64GB host RAM and120GB temporary disk at the documented storage rate. Deadline and budget projections conservatively retain the original$0.34/GPU-hour ceiling plus disk. Its canonical local ledger counts prior attempts toward the same$25 ceiling. A detached local watcher is armed before the create mutation; the provider also receives an absolute termination deadline. Account credentials remain local. Only an SSH public key reaches the Pod.

[cloud_worker.py](cloud_worker.py) installs the pinned packages, downloads and hashes the exact public snapshots, and runs [preflight_gpu.py](preflight_gpu.py). The GPU preflight compares every native and optimized matrix entry at the same B8, including both position-control arms, and measures full checkpoint I/O. It is an engineering paragraph, not a scientific calibration fit. The initial workload projection includes all declared fits, evaluation and retrieval; Huginn's initial cost is explicitly a proxy until its own GPU measurement. Failure to fit the budget stops the work without silently reducing N or R.

The worker performs the five main fits and evaluation, then the control fits and evaluation. It waits for a result-bound Ouro interpretation receipt before beginning Huginn. This order does not require a favorable Ouro finding. Huginn then receives its own native parity, memory and measured budget gate before its N100 fit and both evaluation seeds.

The watcher requests a stop before the spending deadline. Once the worker is quiescent, it retrieves the full result inventory, verifies every byte locally and terminates the owned Pod. Worker success, scientific completion, artifact retrieval and provider termination have separate receipts. A stopped partial run is preserved as partial evidence. The provider deadline remains the final spending backstop if local supervision is interrupted.

## Offline plan

From the extracted bundle, run `run_refits.py --plan --all --ouro-src <ouro_project/src> --snapshot <pinned Ouro snapshot> --output-dir <new result root>`. The plan validates the source/calibration closure using only the standard library. Controls and Huginn have corresponding `--plan` modes. Production requires the actual lease-derived `--stop-at-utc`; use the worker to supply consistent paths and runtime settings.

Historical B32 and new B8 floating-point differences remain a comparison limitation. No new scientific fit or recovery result is claimed by this preparation document.

The first allocation request on8 September returned a completed provider supply rejection with no pod identifier. V4 preserves the same42 scientific source records and run specification as V3, adding the corrected local rejection reconciliation controller and its116-case CPU proof. This recognizes only the exact observed completed rejection, retains the response provenance, and still requires three fresh account-verified absence checks. Unknown outcomes remain unresolved until they can be reconciled safely. All failed attempts remain in the canonical budget ledger.

The second RTX4090 request returned the same completed rejection and closed automatically after three fresh absence checks. V5 selects the cheaper RTX3090 without changing the42 scientific inputs or the conservative deadline rate. Its125-case local controller proof includes rejection of a$0.23 assigned price, preserved recognition of historical RTX4090 leases, and rejection of a substituted GPU. The actual rental still must pass the full GPU preflight before fitting.
