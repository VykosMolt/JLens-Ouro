# Rental preparation — 8 September 2026

The user accepted the proposed $20 combined budget and said they would arrange the funds. Record $10 for the five Ouro N100 fits and $10 for the conditional Huginn R8 N100 pilot. Funding availability has not been verified. This preparation creates no rental and sends no files externally.

`ouro_sources.tar.gz` is a local source/calibration staging bundle, with a SHA-256 manifest. It contains the current J-Lens package, the unchanged Ouro adapter and evidence helpers, the validated optimized per-prompt engine/benchmark, calibration lists and their original audit, and the CPU estimator checks. It excludes weights, existing Jacobian binaries, credentials and evaluation outcomes. Files copied from the original project remain unchanged there. Relative paths inside the archive preserve the default model-loading layout.

`environment.json` records the actual local package versions used for optimization. In particular, its Torch version is `2.12.0.dev20260407+cu128` and Transformers is `4.54.1`. The old project's runtime lock uses a different Torch version. The current J-Lens project metadata requests Transformers >=5.5. Neither should silently replace this experiment's runtime. Use the packaged sources on `PYTHONPATH`; resolve exact Torch wheel availability before renting, or validate and record any deliberately selected replacement environment before scientific fits.

After extraction into a fresh directory, install the validated dependencies and obtain the pinned public `ByteDance/Ouro-2.6B` snapshot at revision `1ed04250da1a9936042725d302e81c8fa2ab5abd`. The unchanged adapter expects its files beneath:

```text
ouro_project/artifacts/hf_cache/hub/models--ByteDance--Ouro-2.6B/snapshots/1ed04250da1a9936042725d302e81c8fa2ab5abd/
```

Changing `HF_HOME` alone does not change this default. The snapshot must include weights, remote code and tokenizer/config files. Verify their identities against the existing local snapshot before using them as the pinned model. Do not include an unpinned Hub checkout in a fitted artifact's provenance.

From the extracted directory, the complete fixed-fixture performance benchmark command is:

```bash
export PYTHONPATH="$PWD/jacobian-lens:$PWD/ouro_project/src"
PYTHONDONTWRITEBYTECODE=1 HF_MODULES_CACHE="$PWD/hf_modules" \
HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8 \
PYTORCH_ALLOC_CONF=expandable_segments:True \
python jacobian-lens/research/refit_round_2026-09-07/optimization/benchmark_optimized.py \
  --engine cuda_graph --batch 8 --compress --output benchmark_b8.json
```

The benchmark retains an old `/home/moloch/ouro_project/src` path insertion. On a fresh rental that path does not exist and the explicit `PYTHONPATH` resolves the bundled adapter. Verify `ouro_jlens.recurrent.__file__` and `jlens.__file__` before any run; if that old path exists, remove this ambiguity in a separately recorded portable driver. The package import check is not a GPU or numerical check.

This command times a complete paragraph and checks finite output; it does not independently establish matching-batch parity. Establish that comparison on the rental GPU using the native same-batch calculation, and record device, checkpoint, software, precision and batch before the five fits. Local BF16 tensors are not a cross-GPU bitwise reference. Preserve the observed historical-B32/new-B8 numerical comparability issue in the interpretation.

The optimized per-prompt engine still needs to be connected to a resumable N100 orchestration path with full provenance and cost accounting. The old `fit_lens.py` is included as a reuse reference: it calls stock `jlens.fit` and **does not select the optimized engine**. Do not run that CLI and label its output optimized. Preserve its prompt/model/source/checkpoint integrity rules when integrating the new engine; do not bypass them with an unrecorded global monkeypatch. A partially completed calibration set must not become an N100 fit.

Before any paid launch, complete that orchestration and its meaningful interruption/resume checks. Benchmark and fitting share one $10 Ouro allocation; track total rental wall time and disk charges, and retrieve/seal outputs before termination. Freeze five fits and all source/target/position settings independently of outcomes. Ouro target/position checks remain a separate scope/cost question; do not silently spend the Huginn allocation on them. Huginn remains conditional on finishing the Ouro adjudication and validating its adapter, initialization and coda. No Huginn implementation is asserted to be complete by this bundle.
